#!/bin/sh

java -jar visualizer.jar
