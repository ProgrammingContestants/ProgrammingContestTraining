package vmap.model;

public enum Cell
{
	ROBOT,
	WALL,
	ROCK,
	LAMBDA,
	CLOSED_LIFT,
	OPEN_LIFT,
	EARTH,
	TRAMPOLINE,
	TARGET,
	BEARD,
	RAZOR,
	HOROCK,
	EMPTY,
}
