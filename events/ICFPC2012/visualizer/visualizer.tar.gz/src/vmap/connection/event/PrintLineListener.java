package vmap.connection.event;

public interface PrintLineListener
{
	public void printLine(String line);
}
