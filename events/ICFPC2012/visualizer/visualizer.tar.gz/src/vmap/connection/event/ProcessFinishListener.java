package vmap.connection.event;

public interface ProcessFinishListener
{
	public void finished(int exitCode);
}
